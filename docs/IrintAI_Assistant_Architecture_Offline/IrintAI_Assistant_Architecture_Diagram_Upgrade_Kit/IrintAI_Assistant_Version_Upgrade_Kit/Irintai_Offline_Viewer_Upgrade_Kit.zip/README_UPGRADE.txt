
IrintAI Assistant Offline Viewer - Upgrade Instructions
==============================================

Thank you for using the IrintAI AssistantOffline Architecture Viewer!

This guide explains how to upgrade your IrintAI Assistant Viewer from one version to the next (for example, from v1.0 to v2.0).

Contents of this Upgrade Kit:
-----------------------------
- upgrade_irintai.bat          --> The one-click upgrade assistant
- update_files/                --> New files for the updated version (v2 or higher)

Upgrade Process:
-----------------
1. Download or receive the 'Irintai_Offline_Viewer_Upgrade_Kit.zip' file.

2. Extract all contents of the ZIP file into a **temporary folder**.

3. Inside the extracted folder, **double-click** the file:
   --> upgrade_irintai.bat

4. The script will:
   - Automatically delete outdated viewer files (HTML, BAT, README, VERSION).
   - Copy over the new version files from 'update_files/' into the main folder.
   - Leave your 'mermaid.min.js' untouched (no need to re-download unless instructed).

5. When the script finishes, **run 'launch_irintai_viewer_smart.bat'** as usual.

Important Notes:
----------------
- Make sure you close any open viewer tabs or browser windows before upgrading.
- Always backup important notes or edits before running an upgrade, if you made personal changes to HTML files.
- If 'mermaid.min.js' ever needs an update, it will be mentioned clearly in the new VERSION.txt.

Version Control:
----------------
- Each release contains a VERSION.txt file describing changes.
- Please refer to it to understand what was improved or modified.

Support:
--------
For any issues, please contact the IrintAI Assistant Project Team.

-- IrintAI Assistant Project
