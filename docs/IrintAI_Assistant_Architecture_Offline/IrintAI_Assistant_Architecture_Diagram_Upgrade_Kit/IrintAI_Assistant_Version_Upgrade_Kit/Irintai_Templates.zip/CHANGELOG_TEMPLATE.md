
# IrintAI Assistant Offline Viewer - Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]
- Planned features and improvements.

## [Version X.X] - YYYY-MM-DD
### Added
- [New features]

### Changed
- [Updates to existing functionality]

### Fixed
- [Bug fixes]

### Removed
- [Deprecated or removed features]

---
*This changelog follows the [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) format for clarity and professionalism.*
